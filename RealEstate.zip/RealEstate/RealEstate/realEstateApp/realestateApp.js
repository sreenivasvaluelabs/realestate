﻿(function () {
    angular.module("realestateApp", []);
}());